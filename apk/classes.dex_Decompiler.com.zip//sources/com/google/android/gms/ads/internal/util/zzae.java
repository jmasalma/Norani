package com.google.android.gms.ads.internal.util;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
public final /* synthetic */ class zzae implements Runnable {
    public final /* synthetic */ zzau zza;

    public /* synthetic */ zzae(zzau zzau) {
        this.zza = zzau;
    }

    public final void run() {
        this.zza.zzs(this.zza.zza);
    }
}
