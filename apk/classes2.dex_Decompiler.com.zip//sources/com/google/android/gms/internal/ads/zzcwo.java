package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.client.zze;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
public interface zzcwo {
    void zzs(zze zze);
}
