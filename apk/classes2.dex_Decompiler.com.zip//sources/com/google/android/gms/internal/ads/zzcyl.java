package com.google.android.gms.internal.ads;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
public final /* synthetic */ class zzcyl implements zzdbs {
    public final void zza(Object obj) {
        ((zzcyo) obj).zzv();
    }
}
