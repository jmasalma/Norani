package com.google.android.gms.internal.ads;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
public final /* synthetic */ class zzczu implements zzdak {
    public final void zza(Object obj) {
        ((zzexy) obj).zzds();
    }
}
