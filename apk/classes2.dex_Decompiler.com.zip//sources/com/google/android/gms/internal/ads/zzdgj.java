package com.google.android.gms.internal.ads;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
final class zzdgj {
    static final zzdgk zza = new zzdgk();
}
