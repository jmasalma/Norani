package com.google.android.gms.internal.ads;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
public final /* synthetic */ class zzgkc implements zzgob {
    public final zzgfm zza(zzgpb zzgpb) {
        return zzgkf.zzb((zzgoy) zzgpb);
    }
}
