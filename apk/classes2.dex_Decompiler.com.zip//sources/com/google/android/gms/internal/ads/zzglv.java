package com.google.android.gms.internal.ads;

/* compiled from: com.google.android.gms:play-services-ads@@24.5.0 */
public final /* synthetic */ class zzglv implements zzgof {
    public final zzgpb zza(zzgfm zzgfm) {
        return zzglz.zzd((zzgka) zzgfm);
    }
}
